$('#loading').click(function(){
    window.location="../loading/loading.html"
})
$('#startButton').click(function(){
    window.location="../loading/loading.html"
})