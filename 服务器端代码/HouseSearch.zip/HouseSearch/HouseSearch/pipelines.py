# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import redis
import pandas as pd
import MySQLdb
import MySQLdb.cursors
from twisted.enterprise import adbapi
from scrapy.utils.project import get_project_settings

settings = get_project_settings()


class HousesearchPipeline(object):
    def process_item(self, item, spider):
        return item


"""
将爬取的房屋信息存入数据库
    同步插入, 解析完成后再插入数据库(scrapy解析的速度远大于数据库的插入速度)
"""


class DBPipeline(object):
    def __init__(self):
        self.db = MySQLdb.connect(
            host=settings.get('MYSQL_HOST'),
            db=settings.get('MYSQL_DBNAME'),
            user=settings.get('MYSQL_USER'),
            passwd=settings.get('MYSQL_PASSWD'),
            charset='utf8',
            use_unicode=True
        )
        self.cursor = self.db.cursor()

    def process_item(self, item, spider):
        insert_sql_house = """insert into house(status,price,pay_way,title,capacity,address,community,community_url, introduction) VALUES(%d,\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\',\'%s\') """
        insert_sql_user = """insert into user(nickname,phone,user_url) VALUES(\'%s\',\'%s\',\'%s\')"""
        insert_sql_house_user = """insert into user_house(user_id, house_id, status) VALUES(%d,%d,%d)"""

        try:
            # 插入house表
            self.cursor.execute(insert_sql_house % (
                item['status'], item['price'], item['pay_way'], item['title'], item['capacity'], item['address'], item['community'], item['community_url'], item['introduction']))
            house_id = self.db.insert_id()
            self.db.commit()
            # 插入user表
            self.cursor.execute(
                insert_sql_user % (item['house_agent'], item['house_agent_phone'], item['house_agent_url']))
            user_id = self.db.insert_id()
            self.db.commit()
            # 插入user_house表
            self.cursor.execute(insert_sql_house_user % (user_id, house_id, 0))
            user_house_id = self.db.insert_id()
            self.db.commit()

            print(house_id + ":" + user_id + ":" + user_house_id)

        except Exception as error:
            print(error)
            self.db.rollback()


class DBTwistedPipeline(object):
    def __int__(self, dbpool):
        self.dbpool = dbpool

    @classmethod
    def from_settings(cls, settings):
        dbparams = dict(host=settings.get("MYSQL_HOST"),
                        db=settings.get("MYSQL_DBNAME"),
                        user=settings.get("MYSQL_USER"),
                        passwd=settings.get("MYSQL_PASSWORD"),
                        charset="utf8",
                        cursorclass=MySQLdb.cursors.DictCursor,
                        use_unicode=True)

        dbpool = adbapi.ConnectionPool("MySQLdb", **dbparams)
        return cls(dbpool)

    def process_item(self, item, spider):
        query = self.dbpool.runInteraction(self.do_insert, item)
        query.addErrback(self.handle_error, item, spider)  # 异常处理

    def handle_error(self, failure, item, spider):
        print(failure)

    def do_insert(self, cursor, item):
        insert_sql, params = item.get_insert_sql()
        cursor.execute(insert_sql, params)
