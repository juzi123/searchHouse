# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy
import re
import datetime
from scrapy.loader import ItemLoader
from scrapy.loader.processors import MapCompose, TakeFirst, Join


def remove_comment_tags(value):
    # 去掉tag中提取的评论
    if "评论" in value:
        return ""
    else:
        return value


def return_value(value):
    return value


def get_nums(value):
    match_re = re.match(".*?(\d+).*", value)  # 提取评论数

    if match_re:
        nums = int(match_re.group(1))
    else:
        nums = 0

    return nums


def date_convert(value):
    try:
        create_date = datetime.datetime.strptime(value, "%Y%m%d").date()
    except Exception as e:
        create_date = datetime.datetime.now().date()

    return create_date


class HousesearchItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    pass



class HouseDetailItem(scrapy.Item):   # house_detail['status'] = 0
        # house_detail['title'] = title
        # house_detail['price'] = price
        # house_detail['pay_way'] = pay_way
        # house_detail['capacity'] = capacity
        # house_detail['address'] = address
        # house_detail['community'] = community
        # house_detail['community_url'] = community_url
        # house_detail['house_agent'] = house_agent
        # house_detail['introduction'] = introduction
    longtitude = scrapy.Field()
    latitude = scrapy.Field()
    status = scrapy.Field() # 空房或者已入住
    price = scrapy.Field()  # 租金
    pay_way = scrapy.Field()  # 租金支付方式: 整租, 半年付
    title = scrapy.Field()  # 求租标题: 无中介费赚差价的日短租直看房源家庭式海悦国际公寓
    capacity = scrapy.Field()  # 两室一厅 89平
    address = scrapy.Field()  # 青岛中路85号
    community = scrapy.Field() #  怡安苑
    community_url = scrapy.Field()
    introduction = scrapy.Field() # 房屋介绍
    house_agent = scrapy.Field()  # 房主
    house_agent_url = scrapy.Field()  # 房主页面链接
    house_agent_phone = scrapy.Field()  # 房主电话

