# -*- coding: utf-8 -*-
import scrapy
import datetime
import re
from scrapy.http import Request
from HouseSearch.items import HouseDetailItem
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
import hashlib


class GanjiSpider(scrapy.Spider):
    name = "ganji"
    allowed_domains = ["wei.ganji.com"]
    start_urls = ['http://bj.ganji.com/fang1/']
    agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36"
    headers = {
        # "HOST": "j1.58cdn.com.cn",
        # "Referer": "http://webim.58.com/index?p=rb",
        "User-Agent": agent
    }

    #     rules = (
    #         Rule(LinkExtractor(allow=(r'/zufang/(pn\d+/)?', r'/hezu/(pn\d+/)?', r'/chuzu/(pn\d+/)?'),restrict_css='div.main > div.content > div.listBox > ul.listUl > li'),
    # follow=True),
    #         Rule(LinkExtractor(allow=(r'/zufang/\d+x\.shtml', r'/hezu/\d+x\.shtml', r'/chuzu/\d+x\.shtml')),
    #              callback='parse_item'),
    #     )

    def parse(self, response):
        detail_url_list = response.xpath('//div[@class="des"]/h2/a/@href').extract()
        for j in range(1, len(detail_url_list) + 1):
            yield Request(url=detail_url_list[j], callback=self.parse_detail, dont_filter=True)
        # bottom_ad_li (li) >  pager(div) > next(a)

        next_page_url = response.xpath(
            "//li[@id='bottom_id_li']/div[@class='pager']/a[@class='next']/@href").extract_first()
        if next_page_url:
            yield Request(url=next_page_url, callback=self.parse, dont_filter=True)

        pass
