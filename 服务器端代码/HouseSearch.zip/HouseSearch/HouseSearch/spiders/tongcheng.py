# -*- coding: utf-8 -*-
import scrapy
import datetime
import re
from scrapy.http import Request
from scrapy.loader import ItemLoader

from HouseSearch.items import HouseDetailItem
from scrapy.spiders import Rule
from scrapy.linkextractors import LinkExtractor
import hashlib
import random
import requests
from selenium import webdriver
from scrapy.utils.project import get_project_settings

settings = get_project_settings()

# def get_md5(url):
#     if isinstance(url, str):
#         url = url.encode("utf-8")
#     m = hashlib.md5()
#     m.update(url)
#     return m.hexdigest()
#

class TongchengSpider(scrapy.Spider):
    name = "tongcheng"
    allowed_domains = ["weihai.58.com"]
    start_urls = ['http://weihai.58.com/chuzu/pn1/']
    agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.1.1 Safari/603.2.4",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.79 Safari/537.36 Edge/14.14393",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/603.2.5 (KHTML, like Gecko) Version/10.1.1 Safari/603.2.5",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36 Edge/15.15063",
        "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",
        "Mozilla/5.0 (iPad; CPU OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1",
        "Mozilla/5.0 (Windows NT 6.1; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0",
        "Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.1 Safari/603.1.30",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 5.1; rv:52.0) Gecko/20100101 Firefox/52.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.109 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/58.0.3029.110 Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/603.2.5 (KHTML, like Gecko) Version/10.1.1 Safari/603.2.5",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.104 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64; rv:45.0) Gecko/20100101 Firefox/45.0",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:53.0) Gecko/20100101 Firefox/53.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.86 Safari/537.36 OPR/46.0.2597.32",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/59.0.3071.109 Chrome/59.0.3071.109 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:53.0) Gecko/20100101 Firefox/53.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 OPR/45.0.2552.898",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
        "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36 OPR/46.0.2597.39",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:54.0) Gecko/20100101 Firefox/54.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/602.4.8 (KHTML, like Gecko) Version/10.0.3 Safari/602.4.8",
        "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; Touch; rv:11.0) like Gecko",
        "Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36",
    ]

    headers = {
        "HOST": "weihai.58.com",
        "Referer": "http://webim.58.com/chuzu/pn1",
        "User-Agent": agents[random.randint(0, 78)]
    }

    rules = (
        Rule(LinkExtractor(allow=(r'/zufang/(pn\d+/)?', r'/hezu/(pn\d+/)?', r'/chuzu/(pn\d+/)?'),
                           restrict_css='div.main > div.content > div.listBox > ul.listUl > li'),
             follow=True),
        Rule(LinkExtractor(allow=(r'/zufang/\d+x\.shtml', r'/hezu/\d+x\.shtml', r'/chuzu/\d+x\.shtml')),
             callback='parse_detail'),
    )



    """
        获取最大页数
        遍历每一页得到每页的所有项
        遍历每一项的详情页href得到url的集合
        依次进入详情页, 取出主要信息
        主要信息保存到数据库
    """

    def __init__(self):
        super(scrapy.Spider, self)
        self.options = webdriver.ChromeOptions()
        # 解决ERROR:ssl_client_socket_impl.cc(1098)] handshake failed问题
        self.options.add_argument("--ignore-certificate-errors")
        self.options.add_experimental_option("prefs", {"profile.managed_default_content_settings.images": 2})
        self.driver = webdriver.Chrome(chrome_options=self.options,
                                       executable_path=r"F:\chromedriver_win32\chromedriver_win32\chromedriver.exe")
        # self.proxies = settings.get("PROXIES")
        # self.driver.get()


    def parse(self, response):
        # max_page = int(response.xpath('//*[@id="bottom_ad_li"]/div[2]/a[3]/span').extract()[0])

        print("============================列表页==============================\n")
        print(response.body.decode())
        print("\n==========================列表页结束==========================\n")

        detail_url_list = response.xpath('//div[@class="des"]/h2/a/@href').extract()

        print("============================列表url==============================\n")
        print(''.join(detail_url_list))
        print("============================列表url结束==============================\n")

        # 每页列表
        for j in range(1, len(detail_url_list) + 1):
            self.headers['User-Agent'] = self.agents[random.randint(0, 78)]
            yield Request(url=detail_url_list[j], headers=self.headers, callback=self.parse_detail)

        # next_page_url = response.xpath(
        #     "//li[@id='bottom_id_li']/div[@class='pager']/a[@class='next']/@href").extract_first()
        # print(next_page_url)
        # if next_page_url:
        #     yield Request(url=next_page_url, headers=self.headers, callback=self.parse, dont_filter=True)

    """
        解析具体详情页面的房屋和房主信息
    """

    def parse_detail(self, response):
        print("============================详情页==============================\n")
        print(response.body.decode())
        print("============================详情页结束==============================\n")

        house_detail = HouseDetailItem()

        # 标题: 皇冠北区海瞳路多层2楼两室精装修家具家电齐全拎包入住。
        title = response.xpath("//div[@class='house-title']/h1[@class='c_333 f20']/text()").extract_first()

        # 价格: 1800 元/月
        price = response.xpath(
            "//div[@class='house-pay-way f16']/span[@class='c_ff552e']/b/text()").extract_first() + response.xpath(
            "//div[@class='house-pay-way f16']/span[@class='c_ff552e']/text()").extract_first()

        # 整租押一付一
        pay_way = \
            response.xpath("//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span[2]/text()").extract()[
                0].strip() + response.xpath("//div[@class='house-pay-way f16']/span[@class='c_333']/text()").extract()[
                0]

        # 3室2厅2卫145平精装修
        capacity = \
            response.xpath("//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span[2]/text()").extract()[
                1].strip().replace('\xa0', '').replace(' ', '').strip()

        # 所在大体区域: 高区 国际海水浴场长春路
        address = \
            response.xpath("//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span[2]/a/text()").extract()[
                1] + ' ' + \
            response.xpath("//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span[2]/a/text()").extract()[
                2] + response.xpath(
                "//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span[@class='dz']/text()").extract_first().strip().replace(
                ' ', '').replace('\n', '').strip()

        # 小区地址: 新浪屿花园
        community = response.xpath(
            "//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span/a[@class='c_333 ah']/text()").extract()[
            0]

        # 租房: http://weihai.58.com/xiaoqu/xinlangyuhuayuan17/?from=zf
        community_url = response.xpath(
            "//div[@class='house-desc-item fl c_333']/ul[@class='f14']/li/span/a[@class='c_333 ah']/@href").extract()[0]

        # 房屋介绍
        introduction = "<p>" + ','.join(response.xpath(
            "//div[@class='house-word-introduce f16 c_555']/ul[@class='introduce-item']/li/span[2]/em/text()").extract()) + '。</p> ' + ' '.join(
            response.xpath(
                "//div[@class='house-word-introduce f16 c_555']/ul[@class='introduce-item']/li[2]/span[2]//*").extract())

        # 发布人
        house_agent = response.xpath("//div[@id='bigCustomer']/p[@class='agent-name f16 pr']/a/text()").extract_first()
        # url: http://houserent.58.com/landlord/center?infoId=34360901140664
        house_agent_url = response.xpath(
            "//div[@id='bigCustomer']/p[@class='agent-name f16 pr']/a/@href").extract_first()
        phone = response.xpath("//div[@class='house-chat-phone']/span[@class='house-chat-txt']/text()").extract_first()

        print(title)
        print(price)
        print(pay_way)
        print(capacity)
        print(address)
        print(community)
        print(community_url)
        print(introduction)
        print(house_agent)
        print(house_agent_url)
        print(phone)
        print("\n")

        house_detail['status'] = 0
        house_detail['title'] = title
        house_detail['price'] = price
        house_detail['pay_way'] = pay_way
        house_detail['capacity'] = capacity
        house_detail['address'] = address
        house_detail['community'] = community
        house_detail['community_url'] = community_url
        house_detail['introduction'] = introduction
        house_detail['house_agent'] = house_agent
        house_detail['house_agent_url'] = house_agent_url
        house_detail['house_agent_phone'] = phone

        yield house_detail
        # item_loader = ItemLoader(item=HouseDetailItem(), response=response)
        #
        # house_item = item_loader.load_item()
        #
        # yield house_item
