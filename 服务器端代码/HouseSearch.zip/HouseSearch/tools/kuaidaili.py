# -*- coding: utf-8 -*-

__author__ = 'wangqing'
import requests
from scrapy.selector import Selector
import MySQLdb
from time import sleep

conn = MySQLdb.connect(host="127.0.0.1", user="root", passwd="", db="house", charset="utf8")
cursor = conn.cursor()

# 判断ip是否被58给屏蔽
def check_valid_ip(proxy_type, ip, port):
    http_url = "http://weihai.58.com/chuzu/pn1"
    proxy_url = proxy_type + "://" + ip + ":" + port
    # 请求代理失败
    try:
        proxy_dict = {proxy_type:proxy_url}
        response = requests.get(http_url, proxies=proxy_dict)
    except Exception as e:
        print("Exception:" + e)
        print("invalid ip and port{0}:{1}".format(ip, port))
        return False
    # 请求代理成功
    else:
        code = response.status_code
        # 有效
        if code >= 200 and code <300:
            print("effective ip {0}:{1}".format(ip, port))
            return True
        # 无效
        else:
            print("invalid ip and port{0}:{1}".format(ip, port))
            return False


# 爬取快代理网免费ip代理
def crawl_ips():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.108 Safari/537.36 2345Explorer/8.7.0.16031"}

    for i in range(2352):

        re = requests.get("https://www.kuaidaili.com/free/inha/{0}".format(i), headers=headers)
        selector = Selector(text=re.text)
        all_trs = selector.css("#list tr")
        ip_list = []
        # 每页中有效Ip
        for tr in all_trs[1:]:
            all_texts = tr.css("td::text").extract()

            ip = all_texts[0]
            port = all_texts[1]
            proxy_type = all_texts[3]

            if check_valid_ip(proxy_type, ip, port):
                ip_list.append((ip, port, proxy_type))
                print(ip_list)

        for ip_info in ip_list:
            try:
                cursor.execute("insert proxy_ip(ip,port,proxy_type) VALUES('{0}','{1}','{2}')".format(ip_info[0], ip_info[1],ip_info[2]))
                conn.commit()
            except Exception as e:
                print("Exception: " + str(e))
                continue

        sleep(3)


class GetIp(object):
    # 删除无用的ip
    def delete_ip(self, ip):

        delete_sql = "DELETE FROM `proxy_ip` WHERE `ip`={0}".format(ip)
        cursor.execute(delete_sql)
        conn.commit()
        return True

    # 判断ip是否可用
    def judge_ip(self, ip, port):

        http_url = "http://weihai.58.com/chuzu/"
        proxy_url = "https://{0}:{1}".format(ip, port)
        try:
            proxy_dict = {
                "https": proxy_url
            }
            response = requests.get(http_url, proxies=proxy_dict)
        except Exception as e:
            print("invalid ip and port")
            self.delete_ip
            return False
        else:
            code = response.status_code
            if code >= 200 and code < 300:
                print("effective ip")
                return True
            else:
                print("invalid ip and port")
                self.delete_ip(ip)
                return False

    # 从数据库中随机获取一个可用的ip
    def get_random_ip(self):
        sql = "SELECT `ip`, `port` FROM `proxy_ip` order by RAND() LIMIT 1"
        res = cursor.execute(sql)
        for ip_info in cursor.fetchall():
            ip = ip_info[0]
            port = ip_info[1]
            judge_re = self.judge_ip(ip, port)
            if judge_re:
                print("http://{0}:{1}".format(ip, port))
                return "http://{0}:{1}".format(ip, port)
            else:
                return self.get_random_ip()


if __name__ == "__main__":
    # get_ip = GetIp()
    # get_ip.get_random_ip()
    crawl_ips()
