# # -*- coding: utf-8 -*-
# __author__ = 'wangqing'
#
from scrapy.cmdline import execute
import sys
import os
import time

while True:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    execute(["scrapy", "crawl", "tongcheng"])
    time.sleep(86400)  # 每天执行一次

# 这是一个使用Python连接数据库并把数据放入DataFrame的方法
# import MySQLdb
# import pandas as pd
# from pandas import DataFrame
#
# db = MySQLdb.connect(host="127.0.0.1", user="root", passwd="", db="space")
# cursor = db.cursor()
# # 查询数据
# cursor.execute("SELECT * from user_house where id>560")
# data = cursor.fetchall()
# # 插入一条数据
# img = "\\20170922\\63aeaa459b9e7ec515f6d3c7a8431c21.jpg"
# sql = """insert into image(url) VALUES(\'%s\') """ % (img)
# cursor.execute(sql)
# id = db.insert_id()
# db.commit()
# cursor.execute("""insert into user_house(user_id, house_id,status) VALUES(%d, %d, %d) """%( 1, 576, 1))
# id2 = db.insert_id()
# db.commit()
# cursor.execute("""insert into user_house(user_id, house_id,status) VALUES(%d, %d, %d) """%( id, id2, 1))
# id3 = db.insert_id()
# db.commit()
# # 这里必须把fetch回来的data转换为list的格式，否则DataFrame会在初始化的时候报错。
#
# data = list(data)
# data = [list(i) for i in data]
#
# df = DataFrame(data, columns=["A", "B", "C", "D"])
#
# print(df)
# print(id)
# print(id2)
# print(id3)
