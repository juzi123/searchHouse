<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

use think\Route;

//轮播图
Route::post('api/:version/banner/banner_img', 'api/:version.Banner/addBannerImg');
Route::get('api/:version/banner/banner_img', 'api/:version.Banner/getBannerImg');

//查询空房
Route:: get('api/:version/house/spare_rooms', 'api/:version.House/selectRoom');
//获取所有房间信息,包括多对多关联的图片
Route::get('api/:version/house/all_rooms', 'api/:version.House/getRoomInfo');
//获取某个主题房间的评论信息
Route::get('api/:version/house/get_comments', 'api/:version.House/getCommentInfo');
//添加房屋信息
Route::post('api/:version/house/add_house', 'api/:version.House/addHouse');
//修改房屋状态失败
Route::get('api/:version/house/change_house_status', 'api/:version.House/changeHouseStatus');
//获取所有待出租房屋信息
Route::get('api/:version/house/get_all_spare_house', 'api/:version.House/getAllSpareHouse');
//房主获取自己发布所有租房信息
Route::get('api/:version/house/get_public_house', 'api/:version.House/getPublicHouseByHouseOwner');
//房主删除发布房屋的信息
Route::get('api/:version/house/remove_public_house', 'api/:version.House/removePublicHouse');


//用户注册
Route::post('api/:version/user/register', 'api/:version.User/register');
//用户登录
Route::post('api/:version/user/login', 'api/:version.User/login');
//添加房屋收藏信息
Route::get('api/:version/user/add_house_fav', 'api/:version.User/addFavInfo');
//获取用户收藏的房屋信息
Route::get('api/:version/user/get_house_fav', 'api/:version.User/getFavInfo');
//删除用户对某房屋的收藏
Route::get('api/:version/user/delete_house_fav', 'api/:version.User/deleteFav');
//获取用户的user表中的所有信息
Route::get('api/:version/user/user_info', 'api/:version.User/getUserInfo');

//获取某个用户对于房间的评论
Route::get('api/:version/user/get_comments', 'api/:version.User/getComments');
//添加用户的评论, 关于某个房间
Route::post('api/:version/user/add_comments', 'api/:version.User/addComments');


//获取所有主题
Route::get('api/:version/theme/all_themes', 'api/:version.theme/getAllThemes');


//excel转存至数据库
Route::get('api/:version/house/convert', 'api/:version.House/excelToMySQL');
//接入高德API获取经纬度坐标
Route::get('api/:version/house/getlongla', 'api/:version.House/getLongitudeLatitude');
