<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 17:14
 */

namespace app\api\controller\v1;

use app\api\model\User as UserModel;
use app\api\model\UserHouse as UserHouseModel;
use app\api\model\Comment as CommentModel;
use app\api\model\HouseComment as HouseCommentModel;
use app\api\model\UserComment as UserCommentModel;
use app\api\model\UserHouse;
use app\lib\exception\AddCommentsException;
use app\lib\exception\BaseException;
use app\lib\exception\SuccessMessage;
use lib\exception\QueryCommentException;
use lib\exception\QueryUserInfoException;
use app\api\model\House as HouseModel;
use think\Exception;

/**
 * Class User
 * @package app\api\controller\v1
 * 4009: 房主删除发布房屋信息失败
 * 4008: 用户取消房屋收藏信息失败
 * 4007: 用户添加收藏房屋信息失败
 * 4006: 用户名被注册
 * 4005: 用户登录用户名错误
 * 4004: 用户名尚未注册就登录
 * 4003: 注册用户失败, 插入用户注册信息至数据库失败
 */
class User
{
    /**
     * @param $username
     * @param $password
     * @param $phone
     * @throws BaseException
     * @throws SuccessMessage
     *
     */
    public function register($username, $password, $phone)
    {
        $userModel = new UserModel();
        if ($userModel->notRegistered($username)) {

            if ($userModel->insertNewUser($username, md5($password), $phone)) {
                throw new SuccessMessage();
            } else {
                throw new BaseException(["msg" => "注册失败", "errorCode" => 4006, "code" => 200]);
            }
        } else {
            throw new BaseException(["msg" => "用户名已被注册", "errorCode" => 4003, "code" => 200]);
        }

    }

    public function login($username, $password)
    {
        $userModel = new UserModel();
        $res = $userModel->checkUser($username, md5($password));
        if ($userModel->errorCode != 0) {
            throw new BaseException([
                "msg" => $userModel->msg,
                "code" => $userModel->code,
                "errorCode" => $userModel->errorCode
            ]);
        } else {
            return $res;
        }
    }

    /**
     * 获取用户所有的信息
     * @param array $userId
     * @return false|static[]
     * @throws QueryUserInfoException
     */
    public function getUserInfo($userId = [])
    {
        $userModel = new UserModel();
        $userInfo = $userModel->queryUserInfo($userId);

        if (!$userInfo) {
            throw new QueryUserInfoException();
        }
        return $userInfo;
    }

    /**
     * 获取用户收藏的房屋
     * @param $userId
     * @return false|\PDOStatement|string|\think\Collection
     */
    public function getFavInfo($userId)
    {
        $userHouseModel = new UserHouseModel();
        $roomFav = $userHouseModel->getFavHouse($userId);

        return $roomFav;
    }

    public function addFavInfo($userId, $houseId)
    {

        $userHouseModel = new UserHouseModel();
        if ($userHouseModel->addFavItem($userId, $houseId)) {
            throw new SuccessMessage();
        } else {
            throw new BaseException(["msg" => "添加收藏房屋失败", "code" => 200, "errorCode" => 4007]);
        }
    }

    public function deleteFav($userId, $houseId)
    {
        $userHouseModel = new UserHouseModel();
        if ($userHouseModel->deleteFavItem($userId, $houseId)) {
            throw new SuccessMessage();
        } else {
            throw new BaseException(["msg" => "取消收藏房屋失败", "code" => 200, "errorCode" => 4008]);
        }
    }

    /**
     *  获取指定用户的所有评价(对房屋) user->comment->house
     * @param $userId
     * @return false|\PDOStatement|string|\think\Collection
     * @throws QueryCommentException
     */
    public function getComments($userId) //userId必须传递
    {
        $userModel = new UserModel();
        $comments = $userModel->queryComments($userId);

        if (empty($comments)) {
            throw new  QueryCommentException();
        }

        return $comments;
    }

    /**
     *  评论添加, 现在comment表中添加评论信息, 再在user_comment表中添加多对多关系, 再在house_comment表中添加多对多关系
     * @throws AddCommentsException
     * @throws SuccessMessage
     */
    public function addComments()
    {
        $data = input('post.');
        $userId = intval($data["userId"]);
        $houseId = intval($data["houseId"]);
        $comment = $data["comment"];

        $commentModel = new CommentModel();
        $houseCommentModel = new HouseCommentModel();
        $userCommentModel = new UserCommentModel();

        $res = $commentModel->insertComment($comment);

        if ($res) {
            $commentId = $commentModel->getLastInsID();
        } else {
            throw new AddCommentsException();
        }

        if ($houseCommentModel->insertOne($houseId, $commentId) &&
            $userCommentModel->insertOne($userId, $commentId)) {
            throw new SuccessMessage();
        } else {
            throw new AddCommentsException();
        }
    }


}