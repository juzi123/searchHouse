<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 16:07
 */

namespace app\api\controller\v1;

use app\api\model\Image as ImageModel;
use app\api\model\Banner as BannerModel;
use app\lib\exception\InsertException;
use app\lib\exception\SuccessMessage;
use app\lib\exception\UploadFailedException;

class Banner
{
    /**
     * 权限控制
     *  添加图片只有管理员
     */


    /**
     * 单张banner图片的添加
     */
    public function addBannerImg($keyword)
    {
        $img = request()->file('image');    //获取表单上传的图片

        if ($img) {         //成功获取
            $info = $img->move(ROOT_PATH . 'public' . DS . 'uploads');

            if ($info) {    //成功移到upload目录

                $url = DS . $info->getSaveName();
                try {
                    $imageModel = new ImageModel();
                    $bannerModel = new BannerModel();
                    $res = $imageModel->insertImage($url);
                    $bannerModel->insertImage($imageModel->getLastInsID(), $keyword);

                    return new SuccessMessage([
                        'code' => 200,
                        'errorCode' => 0,
                        'msg' => '上传图片成功'
                    ]);

                } catch (InsertException $e) {
                    throw $e;
                }

            } else {        //移动失败
                throw new UploadFailedException([
                    'msg' => '上传图片至指定位置失败',
                    'errorCode' => 20000,
                    'code' => 400
                ]);
            }

        } else {            //未获取到图片
            throw new UploadFailedException([
                'msg' => '未获取到图片,请检查上传问题',
                'errorCode' => 10001,
                'code' => 400
            ]);
        }
    }

    /**
     * 获取banner轮播图片
     */
    public function getBannerImg()
    {
        $bannerModel = new BannerModel();
        $images = $bannerModel->queryBannerImages();
        return $images;
    }


}