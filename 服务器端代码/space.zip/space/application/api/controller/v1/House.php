<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 10:13
 */

namespace app\api\controller\v1;

use app\api\model\House as HouseModel;
use app\api\model\User as UserModel;
use app\api\model\UserHouse as UserHouseModel;
use app\api\model\Comment as CommentModel;
use app\lib\exception\BaseException;
use app\lib\exception\NoSpareRoomException;
use app\lib\exception\SuccessMessage;
use SebastianBergmann\Comparator\ArrayComparatorTest;
use think\Request;


/**
 * Class House
 * @package app\api\controller\v1
 *
 * 3010: 房主添加房屋信息失败
 * 3011: 修改房屋状态失败
 *
 */
class House
{

    /**
     * @param $from_time
     * @param string $people_num
     * @param string $theme_id
     * @return false|\PDOStatement|string|\think\Collection
     * @throws NoSpareRoomException
     * 查询空余房间
     */
    public function selectRoom($from_time, $people_num = "", $theme_id = "")
    {
        $houseModel = new HouseModel();
        $availableRoom = $houseModel->querySpareRoom($from_time, $people_num, $theme_id);

        if (count($availableRoom) == 0) {
            throw new NoSpareRoomException([
                'errorCode' => $houseModel->errorCode,
                'code' => $houseModel->code,
                'msg' => $houseModel->msg
            ]);
        }

        return $availableRoom;
    }

    /**
     * @param array $ids
     * @return false|\PDOStatement|string|\think\Collection
     * 房间所有信息
     */
    public function getRoomInfo($ids = [])
    {
        $houseModel = new HouseModel();
        $roomInfo = $houseModel->queryRoomInfo($ids);

        return $roomInfo;
    }

    /**
     * @param array $houseIds
     * @return false|\PDOStatement|string|\think\Collection
     * 查询房间的评论信息
     */
    public function getCommentInfo($houseIds = [])
    {
        $houseModel = new HouseModel();
        $favInfo = $houseModel->queryRoomComment($houseIds);
        $favInfo->visible(['comment']);
        return $favInfo;
    }

    /**
     * @param $user_id 房主id
     * @param $capacity 几室几厅
     * @param $pay_way 付款方式: 年付还是月付
     * @param $price 价格: 1700元/月 200元/天 10000元/年
     * @param int $status 0: 空房 1: 已入住
     * @param $area 面积: 80平
     * @param $title 标题
     * @param $longitude 经度
     * @param $latitude 维度
     * @param $address 具体地址: 即高德地图返回的地址
     * @param $introduction : 房主对出售房的介绍
     * @param $from_time : 开始出租时间
     * @param $to_time : 结束出租时间
     * @throws BaseException
     * @throws SuccessMessage
     */
    public function addHouse($user_id, $capacity, $pay_way, $price, $status = 0, $area, $title, $longitude, $latitude, $address, $introduction, $from_time, $to_time)
    {
        $houseModel = new HouseModel();
        if ($house_id = $houseModel->insertHouse($capacity, $pay_way, $price, $status, $area, $title, $longitude, $latitude, $address, $introduction, $from_time, $to_time)) {
            if ($res_id = (new UserHouseModel())->addItem($user_id, $house_id)) {
                throw new SuccessMessage();
            } else {
                $houseModel->deleteHouse($house_id);
                throw new BaseException(["msg" => "添加房屋信息失败", "code" => 200, "errorCode" => 3010]);
            }
        } else {
            throw new BaseException(["msg" => "添加房屋信息失败", "code" => 200, "errorCode" => 3010]);
        }
    }

    /**
     * @param $house_id
     * @param $status
     * @throws BaseException
     * @throws SuccessMessage
     * 修改房屋状态, 房屋已出租1或空房0
     *
     */
    public function changeHouseStatus($house_id, $status)
    {
        if ((new HouseModel())->changeStatus($house_id, $status)) {
            throw new SuccessMessage();
        } else {
            throw new BaseException([
                "msg" => "修改房屋状态失败",
                "code" => 200,
                "errorCode" => 3011
            ]);
        }
    }

    /**
     * @return false|\PDOStatement|string|\think\Collection
     * 获取威海所有待出租房屋信息
     */
    public function getAllSpareHouse()
    {
        $userHouseModel = new UserHouseModel();
        return $userHouseModel->getAllSpareHouse();

    }

    /**
     * @param $user_id
     * @return array
     * 房主获取自己发布的房屋信息
     */
    public function getPublicHouseByHouseOwner($user_id)
    {
        // 房主获取所有自己发布房屋的信息, 包括已出租和空房
        $userHouseModel = new UserHouseModel();
        $data = $userHouseModel->getPublicHouse();
        $res = array();
        for ($i = 0; $i < count($data); $i++) {
            if ($data[$i]['user']['id'] == $user_id) {

                $item = array();
                $item["id"] = $data[$i]["house"]["id"];
                $item["capacity"] = $data[$i]["house"]["capacity"];
                $item["pay_way"] = $data[$i]["house"]["pay_way"];
                $item["price"] = $data[$i]["house"]["price"];
                $item["price"] = $data[$i]["house"]["price"];
                $item["status"] = $data[$i]["house"]["status"];
                $item["img_id"] = $data[$i]["house"]["img_id"];
                $item["theme_id"] = $data[$i]["house"]["theme_id"];
                $item["area"] = $data[$i]["house"]["area"];
                $item["title"] = $data[$i]["house"]["title"];
                $item["longitude"] = $data[$i]["house"]["longitude"];
                $item["latitude"] = $data[$i]["house"]["latitude"];
                $item["address"] = $data[$i]["house"]["address"];
                $item["introduction"] = $data[$i]["house"]["introduction"];
                $item["fromtime"] = $data[$i]["house"]["fromtime"];
                $item["totime"] = $data[$i]["house"]["totime"];
                $item["create_time"] = $data[$i]["house"]["create_time"];
                $item["update_time"] = $data[$i]["house"]["update_time"];
                $item["delete_time"] = $data[$i]["house"]["delete_time"];


                array_push($res, $item);
            }

        }

        return $res;


    }

    /**
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     * 将58同城上的威海租房信息从excel转储到数据库中
     */
    public function excelToMySQL()
    {
        $reader = new \PHPExcel_Reader_Excel2007();
        $php_excel = $reader->load('F:\www\space\application\api\controller\v1\weihaichuzu.xlsx');
        $sheet = $php_excel->getSheet(0);

        $highestRow = $sheet->getHighestRow();           //取得总行数
        $highestColumn = $sheet->getHighestColumn(); //取得总列数

        for ($j = 2; $j <= $highestRow; $j++)                        //从第二行开始读取数据
        {
            $data_column = array();
            $is_empty = false;

            for ($k = 'A'; $k <= $highestColumn; $k++)            // 判断是否是不完整的记录
            {
                if ((string)$php_excel->getActiveSheet()->getCell("$k$j")->getValue() == null) {
                    $is_empty = true;
                }
            }

            if (!$is_empty) {                                     // 如果这条记录是完整的
                for ($k = 'A'; $k <= $highestColumn; $k++) {
                    $c = 1;
                    $column_title = (string)$php_excel->getActiveSheet()->getCell("$k$c")->getValue();
                    $data_column[$column_title] = $php_excel->getActiveSheet()->getCell("$k$j")->getValue();//读取单元格
                }


                if ($data_column['community'] != null) {

                    $longitude_latitude = $this->getLongitudeLatitude($data_column['community']);

                    $data_column['longitude'] = $longitude_latitude[0];
                    $data_column['latitude'] = $longitude_latitude[1];
                } else {
                    $data_column['longitude'] = null;
                    $data_column['latitude'] = null;
                }

                $house_id = (new HouseModel())->insertFromExcel($data_column);
                $user_id = (new UserModel())->insertFromExcel($data_column);
                (new UserHouseModel())->addItem($user_id, $house_id);
            }
        }
    }

    /**
     * @param $community
     * @return array
     * 获取威海某个小区的经纬度
     */
    public function getLongitudeLatitude($community)
    {
        $url = "http://restapi.amap.com/v3/geocode/geo?key=8bee4af1cca644510b7d5448170a0f8e&address=" . $community . "&city=威海";

        $ch = curl_init();
        //设置选项，包括URL
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);//绕过ssl验证
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        //执行并获取HTML文档内容
        $output = curl_exec($ch);
        //释放curl句柄
        curl_close($ch);

        $res = json_decode($output, true);

        if ($res['info'] == 'OK' && $res['geocodes'] != null) {
            $longitude_latitude = explode(',', $res['geocodes'][0]['location']);
            return $longitude_latitude;
        }
    }

    /**
     * @param $userId
     * @param $houseId
     * @throws BaseException
     * @throws SuccessMessage
     * @throws \think\exception\PDOException
     */
    public function removePublicHouse($userId, $houseId)
    {
        $userHouseModel = new UserHouseModel();
        $houseModel = new HouseModel();
        try {
            if (($userHouseModel)->deletePublicItem($userId, $houseId) &&
                ($houseModel)->deleteHouse($houseId)) {
                throw new SuccessMessage();
            } else {
                $userHouseModel->rollback();
                $houseModel->rollback();
                throw new BaseException(["msg" => "删除发布房屋信息失败", "errorCode" => 4009, "code" => 200]);
            }
        } catch (Exception $e) {
            $userHouseModel->rollback();
            $houseModel->rollback();
            throw new BaseException(["msg" => "删除发布房屋信息失败", "errorCode" => 4009, "code" => 200]);
        }
    }

}