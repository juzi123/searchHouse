<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 18:45
 */

namespace app\api\controller\v1;

use app\api\model\Theme as ThemeModel;


class Theme
{
    public function getAllThemes()
    {
        $themeModel = new ThemeModel();
        $themes = $themeModel->queryAllThemes();

        return $themes;
    }
}