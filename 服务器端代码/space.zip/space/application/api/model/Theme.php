<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 18:55
 */

namespace app\api\model;


class Theme extends BaseModel
{
    protected $autoWriteTimestamp = true;
    protected $hidden = ['delete_time', 'create_time', 'update_time'];

    public function queryAllThemes()
    {
        $themes = self::with('image')->select();
        return $themes;
    }

    public function image()
    {
        return $this->belongsTo('Image', 'topic_img_id', 'id');
    }
}