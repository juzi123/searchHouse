<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 16:48
 */

namespace app\api\model;


use think\Model;

class Image extends Model
{
    protected $autoWriteTimestamp = true;
    protected $hidden = ['delete_time', 'update_time', 'create_time', 'id', 'pivot'];

    public function insertImage($url)
    {
        return self::data(['url' => $url])->save();
    }

    public function getUrlAttr($value)
    {
        return config('setting.img_prefix') . $value;
    }
}