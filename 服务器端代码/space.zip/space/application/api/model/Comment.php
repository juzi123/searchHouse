<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 18:14
 */

namespace app\api\model;


class Comment extends BaseModel
{
    protected $hidden = ['pivot'];

    public function insertComment($comment)
    {
        $res = self::data(['comment' => $comment])->save();
        if ($res) {
            return true;
        } else {
            return false;
        }

    }

    public function user()
    {
        return $this->belongsToMany("User", "UserComment", "user_id", "comment_id");
    }

    public function house()
    {
        return $this->belongsToMany("House", "HouseComment", "house_id", "comment_id");
    }
}