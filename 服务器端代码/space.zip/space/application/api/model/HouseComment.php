<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 17:32
 */

namespace app\api\model;


class HouseComment extends BaseModel
{
    public function insertOne($houseId, $commentId)
    {
        self::data([
            'house_id' => $houseId,
            'comment_id' => $commentId
        ])->save();

        return true;
    }
}