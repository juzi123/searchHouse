<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 17:20
 */

namespace app\api\model;


class User extends BaseModel
{
    protected $hidden = ["pivot"];
    public $errorCode = 0;
    public $code;
    public $msg;

    public function notRegistered($username)
    {
        $res = $this->where('nickname', '=', $username)->find();
        if (count($res) == 0) return true;
        else return false;
    }

    public function checkUser($username, $password)
    {
        $res_name = $this->where('nickname', '=', $username)->find();
        $res_user = $this->where('nickname', '=', $username)->where('password', '=', $password)->find();

        if (count($res_name) == 0) {
            $this->errorCode = 4004;
            $this->code = 200;
            $this->msg = "用户名尚未注册";
        } else if (count($res_user) == 0) {
            $this->code = 200;
            $this->msg = "密码错误";
            $this->errorCode = 4005;
        } else return $res_user;
    }

    public function insertNewUser($username, $password, $phone)
    {

        return $this->data([
            "nickname" => $username,
            "password" => $password,
            "phone" => $phone

        ])->save(); // 返回成功插入的条数
    }

    /**
     * @param $userId
     * @return User[]|false
     * @throws \think\exception\DbException
     */
    public function queryUserInfo($userId)
    {
        $userInfo = self::all($userId);

        return $userInfo;
    }

    /**
     *  查询用户的收藏
     * @param $userId
     * @return false|\PDOStatement|string|\think\Collection
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function queryFav($userId)
    {
        $favInfo = self::with('houseFav')->select($userId);

        if (!empty($favInfo)) {
            $favInfo[0]['fav'] = true;
        } else {
            $favInfo[0]['fav'] = false;
        }

        return $favInfo;
    }

    /**
     * @param $userId
     * @return false|\PDOStatement|string|\think\Collection
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\ModelNotFoundException
     * @throws \think\exception\DbException
     */
    public function queryComments($userId)
    {
        $comments = self::with(['comment', 'comment.house'])->select($userId);

        return $comments;
    }

    public function houseFav()
    {
        return $this->belongsToMany("House", "UserHouse", "house_id", "user_id");
    }

    public function comment()
    {
        return $this->belongsToMany("Comment", "UserComment", "comment_id", "user_id");
    }

    public function insertFromExcel($data)
    {
        return $this->insertGetId([
            'phone' => $data['phone'],
            'nickname' => $data['landlord'],
            'user_url' => $data['landlord_url']
        ]);
    }
}