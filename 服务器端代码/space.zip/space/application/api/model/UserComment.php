<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 18:41
 */

namespace app\api\model;


class UserComment extends BaseModel
{
    public function insertOne($userId, $commentId)
    {
        self::data([
            'user_id' => $userId,
            'comment_id' => $commentId
        ])->save();

        return true;
    }
}