<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 10:14
 */

namespace app\api\model;

vendor('phpoffice.phpexcel');

class House extends BaseModel
{
    protected $autoWriteTimestamp = true;
    protected $hidden = ["pivot"];

    public $errorCode;
    public $code;
    public $msg;

    public function querySpareRoom($from_time, $people_num, $theme_id)
    {
        //在指定时间段内有空房
        $availableRoom = self::where('status', '=', '0')
            ->where('to_time', '<', $from_time)->select();

        //用空房,且满足人数条件
        if (count($availableRoom) != 0) {
            $availableRoom = self::where('status', '=', '0')
                ->where('to_time', '<', $from_time)
                ->where('capacity', '>=', $people_num)
                ->select();

            if (count($availableRoom) == 0) {
                $this->code = 404;
                $this->errorCode = 30001;
                $this->msg = "指定时间段内有空房, 但不满足人数要求";  //将未添加人数查询的结果返回给客户端

            } else {
                $availableRoom = self::where('status', '=', '0')
                    ->where('to_time', '<', $from_time)
                    ->where('capacity', '>=', $people_num)
                    ->where('theme_id', '=', $theme_id)
                    ->select();

                if (count($availableRoom) == 0) {
                    $this->code = 404;
                    $this->errorCode = 30002;
                    $this->msg = "指定时间段内有空房, 且满足人数要求, 但不满足所选主题";
                }
            }

        } else {
            $this->errorCode = 30000;
            $this->msg = "在指定时间段内没有任何空房";
            $this->code = 404;
        }


        return $availableRoom;

    }

    public function queryRoomInfo($ids = [])
    {
        if (empty($ids)) {
            $roomInfo = self::with('image')->select();
        } else {
            $roomInfo = self::with('image')->select($ids);
        }

        return $roomInfo;
    }

    public function getFromTimeAttr($value)
    {
        return date('Y-m-d H:i:s', $value);
    }

    public function getToTimeAttr($value)
    {
        return date('Y-m-d H:i:s', $value);
    }

    public function image()
    {
        return $this->belongsToMany("Image", "HouseImage", "image_id", "house_id");
    }

    public function queryRoomComment($houseIds = [])
    {
        if (empty($houseIds)) {
            $roomComment = self::with(['comment', 'comment.user'])->select();
        } else {
            $roomComment = self::with(['comment', 'comment.user'])->select($houseIds);
        }

        return $roomComment;
    }

    public function comment()
    {
        return $this->belongsToMany("Comment", "HouseComment", "comment_id", "house_id");
    }

    public function insertHouse($capacity, $pay_way, $price, $status, $area, $title, $longitude, $latitude, $address, $introduction, $from_time, $to_time)
    {
//         $this->data()->save();
        return $this->insertGetId([
            "capacity" => $capacity,
            "pay_way" => $pay_way,
            "price" => $price,
            "status" => $status,
            "area" => $area,
            "title" => $title,
            "longitude" => $longitude,
            "latitude" => $latitude,
            "address" => $address,
            "introduction" => $introduction,
            "fromtime" => $from_time,
            "totime" => $to_time
        ]);
    }

    public function  deleteHouse($house_id)
    {
        $res = $this->where("id", "=", $house_id)->delete();
        if(!$res) return false;
        else return true;
    }

    public function changeStatus($house_id, $status)
    {
        $res = $this->where("id", "=", $house_id)->update(['status' => $status]);
        return $res;
    }

    public function insertFromExcel($data)
    {
        return $this->insertGetId([
            'capacity' => $data['capacity'],
            'pay_way' => $data['pay_way'],
            'price' => $data['price'],
            'title' => $data['title'],
            'address' => (string)$data['location'] . $data['road'],
            'community' => $data['community'],
            'community_url' => $data['community_url'],
            'introduction' => $data['introduction'],
            'longitude' => $data['longitude'],
            'latitude' => $data['latitude']
        ]);
    }
}