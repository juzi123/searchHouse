<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 16:59
 */

namespace app\api\model;


class HouseImage extends BaseModel
{


}