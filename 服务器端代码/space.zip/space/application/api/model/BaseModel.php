<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 16:49
 */

namespace app\api\model;

use think\Model;

class BaseModel extends Model
{

}