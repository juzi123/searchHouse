<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.11
 * Time: 17:22
 */

namespace app\api\model;


class UserHouse extends BaseModel
{
//    protected $hidden = ["id", "user_id", "house_id", "status"];

    public function addItem($user_id, $house_id)
    {
        return $this->insertGetId([
            "user_id" => $user_id,
            "house_id" => $house_id
        ]);
    }

    public function addFavItem($user_id, $house_id)
    {
        return $this->insertGetId([
            "user_id" => $user_id,
            "house_id" => $house_id,
            "status" => 1
        ]);
    }

    public function deleteFavItem($userId, $houseId)
    {
        $res = $this->where("user_id", "=", $userId)->where("house_id", "=", $houseId)->where("status", "=", 1)->delete();

        if (!$res) return false;
        else return true;
    }

    public function deletePublicItem($userId, $houseId)
    {
        $res = $this->where("user_id", "=", $userId)->where("house_id", "=", $houseId)->where("status", "=", 0)->delete();
        if (!$res) return false;
        else return true;
    }

    public function user()
    {
        return $this->belongsTo("User", "user_id", "id");
    }

    public function house()
    {
        return $this->belongsTo("House", "house_id", "id");

    }

    public function getAllSpareHouse()
    {
        return $this->with(['user', 'house'])->where('status', '=', '0')->select();
    }

    public function getPublicHouse()
    {
        return $this->with(['user', 'house'])->where('status', '=', '0')->select();
    }

    public function getFavHouse($userId)
    {
        return $this->with('house')->where("status", "=", 1)->where("user_id", "=", $userId)->select();

    }
}