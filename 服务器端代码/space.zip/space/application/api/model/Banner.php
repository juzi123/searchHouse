<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 17:09
 */

namespace app\api\model;


class Banner extends BaseModel
{
    protected $autoWriteTimestamp = true;

    protected $hidden = ['id', 'image_id', 'create_time', 'update_time', 'delete_time'];

    public function image()
    {
        return $this->belongsTo("Image", "image_id", "id");
    }

    public function insertImage($imageId, $keyword)
    {
        return self::data([
            'image_id' => $imageId,
            'keyword' => $keyword
        ])->save();
    }

    public function queryBannerImages()
    {
        $images = self::with('image')->select();

        return $images;
    }


}