<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 19:19
 */

namespace app\lib\exception;


class InsertException extends BaseException
{
    public $code = 500;
    public $errorCode = 1000;
    public $msg = "插入失败";
}