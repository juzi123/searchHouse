<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.12
 * Time: 18:55
 */

namespace lib\exception;


use app\lib\exception\BaseException;

class QueryUserInfoException extends BaseException
{
    public $code = 404;
    public $errorCode = 40002;
    public $msg = "无法查询到所有用户的信息";
}