<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 18:21
 */

namespace app\lib\exception;


use Exception;
use think\exception\Handle;
use think\Log;
use think\Request;

class ExceptionHandler extends Handle
{
    private $code;
    private $msg;
    private $errorCode;

    public function render(Exception $e)
    {

        if ($e instanceof BaseException) {  //是自定义异常
            $this->code = $e->code;
            $this->errorCode = $e->errorCode;
            $this->msg = $e->msg;

        } else {    //tp5异常

            if (config('app_debug')) {     //调试状态就直接返回tp5错误页面
                return parent::render($e);

            } else {    //生产状态就返回json错误码
                $this->code = 500;
                $this->msg = 'sorry，we make a mistake. (^o^)Y';
                $this->errorCode = 999;
                $this->recordErrorLog($e);
            }
        }

        $request = Request::instance();
        $result = [
            'msg' => $this->msg,
            'errorCode' => $this->errorCode,
            'request_url' => $request = $request->url()
        ];
        return json($result, $this->code);
    }

    /**
     * 写入异常
     */
    public function recordErrorLog(Exception $e)
    {
        Log::init([
            'type' => 'File',
            'path' => LOG_PATH,
            'level' => ['error']
        ]);
        Log::record($e->getMessage(), 'error');

    }


}