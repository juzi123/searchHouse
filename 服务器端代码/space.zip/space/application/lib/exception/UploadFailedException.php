<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.9.22
 * Time: 19:48
 */

namespace app\lib\exception;


class UploadFailedException extends BaseException
{
    public $errorCode = 10001;
    public $msg = '上传失败';
    public $code = 404;
}