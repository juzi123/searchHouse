<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 20:44
 */

namespace app\lib\exception;



class SuccessMessage extends BaseException
{
    public $code = 200;
    public $errorCode = 0;
    public $msg = 'ok';
}