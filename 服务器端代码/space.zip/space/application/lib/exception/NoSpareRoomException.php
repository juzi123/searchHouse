<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 11:04
 */

namespace app\lib\exception;


class NoSpareRoomException extends BaseException
{
    public $code = 404;
    public $errorCode = 30000;
    public $msg = "指定时间段内没有任何空房";
}