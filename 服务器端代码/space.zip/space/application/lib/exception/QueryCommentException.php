<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.12
 * Time: 18:46
 */

namespace lib\exception;


use app\lib\exception\BaseException;

class QueryCommentException extends BaseException
{
    public $code = 404;
    public $errorCode = 40001;
    public $msg = "无法查询到用户的评论";
}