<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.12
 * Time: 18:34
 */

namespace app\lib\exception;


class AddCommentsException extends BaseException
{
    public $code = 404;
    public $errorCode = 40000;
    public $msg = "用户添加评论失败";
}