<?php
/**
 * Created by wangqing.
 * User: ZKRS
 * Date: 2017.10.3
 * Time: 20:06
 */
return [
  'img_prefix' => 'http://www.wangqing.com/space/public/uploads'
];