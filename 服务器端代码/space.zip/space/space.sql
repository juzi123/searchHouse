/*
Navicat MySQL Data Transfer

Source Server         : native
Source Server Version : 50505
Source Host           : www.go.win:3306
Source Database       : space

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2017-10-11 21:59:29
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for banner
-- ----------------------------
DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `image_id` int(11) NOT NULL,
  `keyword` varchar(100) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of banner
-- ----------------------------
INSERT INTO `banner` VALUES ('1', '22', '测试图片', null, '1506525910', '1506525910');
INSERT INTO `banner` VALUES ('2', '31', '测试图片', null, '1507037277', '1507037277');
INSERT INTO `banner` VALUES ('32', '32', '测试图片', null, '1507037297', '1507037297');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('1', '服务很好', '0');
INSERT INTO `comment` VALUES ('2', '服务一般', '0');

-- ----------------------------
-- Table structure for house
-- ----------------------------
DROP TABLE IF EXISTS `house`;
CREATE TABLE `house` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `capacity` int(6) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0-空房\r\n 1-已入住',
  `img_id` int(11) NOT NULL,
  `theme_id` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL COMMENT '房间面积, 单位米平方',
  `title` varchar(10) DEFAULT NULL COMMENT '经度',
  `longtitude` decimal(30,20) DEFAULT NULL,
  `latitude` decimal(30,20) DEFAULT NULL COMMENT '纬度',
  `address` text,
  `introduction` text,
  `fromtime` int(11) DEFAULT NULL,
  `totime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of house
-- ----------------------------
INSERT INTO `house` VALUES ('1', '4', '280.00', '0', '0', '1', '60', '小浣熊小屋', null, null, '环翠区', '玩具小屋,快来体验吧', '1506079865', '1506079869');
INSERT INTO `house` VALUES ('2', '6', '380.00', '0', '1', '2', '80', '玫瑰花小屋', null, null, '高区', '浪漫爱情小屋, 欢饮入驻', '1506079999', '1508079868');

-- ----------------------------
-- Table structure for house_comment
-- ----------------------------
DROP TABLE IF EXISTS `house_comment`;
CREATE TABLE `house_comment` (
  `house_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of house_comment
-- ----------------------------
INSERT INTO `house_comment` VALUES ('1', '1');
INSERT INTO `house_comment` VALUES ('1', '2');
INSERT INTO `house_comment` VALUES ('2', '2');
INSERT INTO `house_comment` VALUES ('2', '1');

-- ----------------------------
-- Table structure for house_image
-- ----------------------------
DROP TABLE IF EXISTS `house_image`;
CREATE TABLE `house_image` (
  `house_id` int(11) NOT NULL,
  `image_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of house_image
-- ----------------------------
INSERT INTO `house_image` VALUES ('1', '4');
INSERT INTO `house_image` VALUES ('2', '32');
INSERT INTO `house_image` VALUES ('1', '22');
INSERT INTO `house_image` VALUES ('1', '15');

-- ----------------------------
-- Table structure for image
-- ----------------------------
DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `delete_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of image
-- ----------------------------
INSERT INTO `image` VALUES ('4', '\\20170922\\63aeaa459b9e7ec515f6d3c7a8431c21.jpg', null, '1506079865', '1506079865');
INSERT INTO `image` VALUES ('5', '\\20170922\\17b7a99578d3731e3fd68b5ce884a1b9.jpg', null, '1506079956', '1506079956');
INSERT INTO `image` VALUES ('6', '\\20170922\\54ac1b5965addc1b554918bb67ed843c.jpg', null, '1506079993', '1506079993');
INSERT INTO `image` VALUES ('7', '\\20170922\\a94cfc3adb5b064e7362b1c69a6e2b00.jpg', null, '1506080102', '1506080102');
INSERT INTO `image` VALUES ('8', '\\20170922\\27c9d014ca422eb6d234e3a6b4164aa7.png', null, '1506080619', '1506080619');
INSERT INTO `image` VALUES ('9', '\\20170922\\562e379fbf3e188f870617c1653677b3.png', null, '1506080787', '1506080787');
INSERT INTO `image` VALUES ('10', '\\20170922\\e571f5ccab89a3eb86722c4f31128aaf.png', null, '1506080875', '1506080875');
INSERT INTO `image` VALUES ('11', '\\20170922\\09882bfb9e008bc0f126297b138061c2.png', null, '1506081454', '1506081454');
INSERT INTO `image` VALUES ('12', '\\20170922\\050485042f6575211e12d1d5fa5691a2.png', null, '1506082372', '1506082372');
INSERT INTO `image` VALUES ('13', '\\20170922\\33e7396b5839e1ea26844c3a95833376.png', null, '1506084160', '1506084160');
INSERT INTO `image` VALUES ('14', '\\20170922\\982fce22639c03da44f4db0a3e014f63.png', null, '1506085123', '1506085123');
INSERT INTO `image` VALUES ('15', '\\20170922\\35b3154c6621664cfa765fb852b8be77.png', null, '1506088043', '1506088043');
INSERT INTO `image` VALUES ('16', '\\20170922\\dee4b51d00b2704038ec872a08107d4c.png', null, '1506088044', '1506088044');
INSERT INTO `image` VALUES ('17', '\\20170922\\a26d95facfb8b35a2b36c976e05b6609.png', null, '1506088044', '1506088044');
INSERT INTO `image` VALUES ('18', '\\20170922\\1ef99603febff9d8f17d4bb56aedd384.png', null, '1506088044', '1506088044');
INSERT INTO `image` VALUES ('19', '\\20170922\\55c2917c53cf9ad840774eb83fb312e2.png', null, '1506088044', '1506088044');
INSERT INTO `image` VALUES ('20', '\\20170922\\752f8fa81c7aa83f2175f626e248d708.png', null, '1506088044', '1506088044');
INSERT INTO `image` VALUES ('21', '\\20170924\\12ebf11c0ef6ddbb38efeaa4d936c983.png', null, '1506249339', '1506249339');
INSERT INTO `image` VALUES ('22', '\\20170927\\98134f64f9d381f29e6e506df20f8638.png', null, '1506525909', '1506525909');
INSERT INTO `image` VALUES ('23', '\\20171003\\55323eac46fedf6bfb0ea4724771171d.png', null, '1507034878', '1507034878');
INSERT INTO `image` VALUES ('24', '\\20171003\\e67493fdf3f042db73819f8c6c0f7b26.png', null, '1507034968', '1507034968');
INSERT INTO `image` VALUES ('25', '\\20171003\\65a20d04c793f45cea1caaaeb94a7a34.png', null, '1507034984', '1507034984');
INSERT INTO `image` VALUES ('26', '\\20171003\\7c045922e67950572cdc9940a02896de.png', null, '1507035042', '1507035042');
INSERT INTO `image` VALUES ('27', '\\20171003\\6de36f03ece04963a9a67c8a76278619.png', null, '1507035134', '1507035134');
INSERT INTO `image` VALUES ('28', '\\20171003\\224aeb934194f9c519cb9cf749dfaf80.png', null, '1507035214', '1507035214');
INSERT INTO `image` VALUES ('29', '\\20171003\\90a9f210493356ad72a9f0229cb2933e.png', null, '1507035286', '1507035286');
INSERT INTO `image` VALUES ('30', '\\20171003\\cf4d4df542b190e60ccbbd9215416f0f.png', null, '1507035435', '1507035435');
INSERT INTO `image` VALUES ('31', '\\20171003\\2565a223b85d4b93b14afa919ff5de46.png', null, '1507037276', '1507037276');
INSERT INTO `image` VALUES ('32', '\\20171003\\c5dbb0c3c414529297afc5d81a0cc835.png', null, '1507037297', '1507037297');

-- ----------------------------
-- Table structure for order_record
-- ----------------------------
DROP TABLE IF EXISTS `order_record`;
CREATE TABLE `order_record` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `house_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `from_time` time NOT NULL COMMENT '租房起始时间',
  `to_time` time NOT NULL COMMENT '租房结束时间',
  `create_time` int(11) NOT NULL COMMENT '生成订单的时间',
  `update_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of order_record
-- ----------------------------

-- ----------------------------
-- Table structure for theme
-- ----------------------------
DROP TABLE IF EXISTS `theme`;
CREATE TABLE `theme` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `topic_img_id` int(11) NOT NULL,
  `delete_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of theme
-- ----------------------------
INSERT INTO `theme` VALUES ('1', '小浣熊玩具主题', '父母陪孩童入驻', '21', null, null, null);
INSERT INTO `theme` VALUES ('2', '浪漫爱情玫瑰主题', '情侣入驻', '22', null, null, null);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(200) DEFAULT NULL,
  `openId` varchar(255) NOT NULL,
  `sex` int(2) DEFAULT NULL COMMENT '0-male, 1-female',
  `head_image_url` varchar(255) DEFAULT NULL COMMENT '头像url来自微信服务器',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'ZKRS', '', '0', null);
INSERT INTO `user` VALUES ('2', 'WANGQING', '', '0', null);

-- ----------------------------
-- Table structure for user_comment
-- ----------------------------
DROP TABLE IF EXISTS `user_comment`;
CREATE TABLE `user_comment` (
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_comment
-- ----------------------------
INSERT INTO `user_comment` VALUES ('1', '1');
INSERT INTO `user_comment` VALUES ('1', '2');

-- ----------------------------
-- Table structure for user_house
-- ----------------------------
DROP TABLE IF EXISTS `user_house`;
CREATE TABLE `user_house` (
  `user_id` int(11) NOT NULL,
  `house_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_house
-- ----------------------------
INSERT INTO `user_house` VALUES ('1', '1');
INSERT INTO `user_house` VALUES ('1', '2');
